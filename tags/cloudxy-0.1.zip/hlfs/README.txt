			LHDFS
	This is a log-structure file system for our project xycloud, which 
is based on hadoop.
	
