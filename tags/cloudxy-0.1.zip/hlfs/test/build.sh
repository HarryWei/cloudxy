#!/bin/bash
../output/bin/mkfs.hlfs -u local:///tmp/testenv/ -s 1048576 -b 8192 -m 1073741824
